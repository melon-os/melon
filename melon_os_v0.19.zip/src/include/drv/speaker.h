#ifndef _SPEAKER_H_
#define _SPEAKER_H_
#include <common_func.h>


extern void Beep_on(ULONG32 time);
//extern void Play_music(UCHAR8 *pucMusicData);
//extern void Beep_demo(UCHAR8 ucMusicId);
#endif
