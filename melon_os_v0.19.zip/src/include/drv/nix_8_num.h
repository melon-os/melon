#ifndef _NIX_8_NUM_H_
#define _NIX_8_NUM_H_
#include <common_func.h>


#define NIX_8_NUM_DASH_SIGN     0x40

extern void NIX8_disp(UCHAR8 *pucData, USHORT16 usRefrashGap);

#endif/*#ifndef _NIX_8_NUM_H_*/
